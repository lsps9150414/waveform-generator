package com.reactlibrary;

import java.util.*;
import android.app.Activity;
import android.content.Context;
import android.media.AudioFormat;
import android.media.AudioManager;
import android.media.AudioTrack;
import android.util.Log;

import java.text.DecimalFormat;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;

import java.util.concurrent.CountDownLatch;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

import java.io.RandomAccessFile;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.io.InputStreamReader;
import java.io.File;
import java.io.InputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.math.*;

public class AudioWaveOut {
	private String modelName;
	private final float max_iAmp = 11f;  //14f   //  Float.MAX_VALUE;//3.4f*(10^13);//16777216;//16777216.0;// 方波幅度<16 ~ 32767>   4.294967296
	private final float min_iAmp = -11f; //-14f  Float.MIN_VALUE;//-3.4f*(10^13);//-16777216;//-16777216.0;//-32767;//0;			-4.294967296
	private float curr_L_iAmp = 1;
	private float curr_R_iAmp = 1;
	private Boolean misbLoop = false;
	private int mLoopCount = -1;
	private int mLFreqHz = 20;// 20HZ
	private int mRFreqHz = 20;// 20HZ
	private String m_data;// 得到的数据
	private int m_lenght;// 得到数据的有效长度
	private int mLorR = 2;//0为左，1为右, 2以左同时, 3以右同时
	private int mLHorL = 1;//1正半周期，0负
	private int mRHorL = 1;//1正半周期，0负
	private int mLFpsi = 1;//1 Pulse, 0 Space
	private int mRFpsi = 1;//1 Pulse, 0 Space

	private int nLeftPos = 0;
	private int nRightPos = 0;
	//private static ReentrantLock lock = new ReentrantLock(true);
	//private static CountDownLatch start_latch = null;
	//private static CountDownLatch end_latch = null;

	private float l_pulseArray[] = null;
	private float l_spaceArray[] = null;

	private float r_pulseArray[] = null;
	private float r_spaceArray[] = null;

	private  ArrayList mLPulseList = new ArrayList();
	private  ArrayList mLSpaceList = new ArrayList();

	private  ArrayList mRPulseList = new ArrayList();
	private  ArrayList mRSpaceList = new ArrayList();

	private int mDataWriteCount = 0;

	private Integer mLPulseCount = 0;
	private Integer mLSpaceCount = 0;

	private Integer mRPulseCount = 0;
	private Integer mRSpaceCount = 0;

//	private double mPerPulse2BCount = 0;
//	private double mPerSpace2BCount = 0;
	private int m_i️SquareWave = 58;
	private int sampleRateInHz = 44100;//44100;//48000 // sampling frequency
	private int mChannel = AudioFormat.CHANNEL_CONFIGURATION_STEREO;//sound track    CHANNEL_CONFIGURATION_MONO;//单声道
	private int mSampBit = AudioFormat.ENCODING_PCM_FLOAT;//Sample rate  TENCODING_PCM_FLOAT  ENCODING_PCM_16BIT//采样精度 ： 16bit  ENCODING_PCM_8BIT// 采样精度 ： 8bit
	private AudioTrack audioTrackF;
	private float[] m_bitDateF = null ;

	private float[] m_L_bitDateF = null ;
	private float[] m_R_bitDateF = null ;

	private int mLPstd = 499;//1~999
	private int mRPstd = 499;//1~999

	private float[] m_bitSpaceDateF = null;
	private float[] m_bitPulseDateF = null;

	private AudioTrackFThread audioTrackThread = null;
	private Boolean misbThreadLoop = true;

	//private TestThread testThread = null;

	private volatile BigDecimal mCloseTime = new BigDecimal(-1);

	//private static volatile long mTestCloseTime = 0;

	private static class SingleTonHoulder{
		public static AudioWaveOut SingleTonHoulder;
		static{
			//try{
				SingleTonHoulder = new AudioWaveOut();
//			}catch (Exception e){
//				SingleTonLeftHoulder = null;
//			}
		}

	}


	public static AudioWaveOut getInstance(){
			return SingleTonHoulder.SingleTonHoulder;
	}

	private AudioWaveOut()// throws Exception
	{
		// AudioTrack创建所需的最小缓冲区大小
			int bufferSize = AudioTrack.getMinBufferSize(sampleRateInHz, mChannel,
					mSampBit);
			//bufferSize = bufferSize*2;
			audioTrackF = new AudioTrack(AudioManager.STREAM_MUSIC,
					sampleRateInHz, mChannel, mSampBit, bufferSize,
					AudioTrack.MODE_STREAM);//MODE_STATIC
			m_bitDateF = new float[bufferSize];
			for (int i =0;i<bufferSize;i++)
				m_bitDateF[i] = (float)0;

			//System.out.println("audioTrackF.bufferSize  : "+bufferSize);

			try {

//			if (mLorR == 0)
//				audioTrackF.setStereoVolume(1.0f, 0.0f);// 设置左右声道音量
//			else if (mLorR == 1)
//				audioTrackF.setStereoVolume(0.0f, 1.0f);// 设置左右声道音量
//			else
//				audioTrackF.setStereoVolume(1.0f, 1.0f);

//			if(misbLoop)
//				audioTrackF.setLoopPoints(0, bufferSize, -1);//设置音频播放循环点
//			else
//				audioTrackF.setLoopPoints(0, bufferSize, mLoopCount);//设置音频播放循环点

			if (audioTrackThread == null) {
				//AudioWaveOut.setEndLatch(2);
				//System.out.println(modelName+" set latch");
				audioTrackThread = new AudioTrackFThread();
				audioTrackThread.start();
				audioTrackF.play();
			}


//			testThread = new TestThread();
//			testThread.start();
			} catch (Exception e) {
				e.printStackTrace();
				//throw new Exception("Initialize audiotrack error!  初始化音频失败");
			}
	}

 	void initAudioTrack()
	{
		// AudioTrack创建所需的最小缓冲区大小
		int bufferSize = AudioTrack.getMinBufferSize(sampleRateInHz, mChannel,
				mSampBit);
		//bufferSize = bufferSize*2;
		audioTrackF = new AudioTrack(AudioManager.STREAM_SYSTEM,
				sampleRateInHz, mChannel, mSampBit, bufferSize,
				AudioTrack.MODE_STREAM);//MODE_STATIC
		m_bitDateF = new float[bufferSize];
		for (int i =0;i<bufferSize;i++)
			m_bitDateF[i] = (float)0;

		//System.out.println("audioTrackF.bufferSize  : "+bufferSize);

		try {

//			if (mLorR == 0)
//				audioTrackF.setStereoVolume(1.0f, 0.0f);// 设置左右声道音量
//			else if (mLorR == 1)
//				audioTrackF.setStereoVolume(0.0f, 1.0f);// 设置左右声道音量
//			else
//				audioTrackF.setStereoVolume(1.0f, 1.0f);

//			if(misbLoop)
//				audioTrackF.setLoopPoints(0, bufferSize, -1);//设置音频播放循环点
//			else
//				audioTrackF.setLoopPoints(0, bufferSize, mLoopCount);//设置音频播放循环点

			if (audioTrackThread == null) {
				//AudioWaveOut.setEndLatch(2);
				audioTrackThread = new AudioTrackFThread();
				audioTrackThread.start();
				audioTrackF.play();
			}

//			testThread = new TestThread();
//			testThread.start();
		} catch (Exception e) {
			e.printStackTrace();
			//throw new Exception("Initialize audiotrack error!  初始化音频失败");
		}
	}

	public void resetting()
	{
		if (audioTrackF == null)
			initAudioTrack();

		sampleRateInHz = 44100;

		mDataWriteCount = 0;

		nLeftPos = 0;
		nRightPos = 0;

		mLPstd = 0;
		mRPstd = 0;

		misbLoop = false;
		mLoopCount = -1;
		//mLorR = 2;
		mLHorL = 1;
		mRHorL = 1;
		m_i️SquareWave = 58;
		mLFreqHz = 20;
		mRFreqHz = 20;
		//misbLoop = true;
		curr_L_iAmp = 1;
		curr_R_iAmp = 1;
	}

	public void resettingPulse()
	{
		if (audioTrackF == null)
			initAudioTrack();

		mLFpsi = 1;
		mRFpsi = 1;

		mDataWriteCount = 0;

		mLPulseCount = 0;
		mLSpaceCount = 0;

		mRPulseCount = 0;
		mRSpaceCount = 0;

		if (l_pulseArray != null)
			l_pulseArray = null;

		if (l_spaceArray != null)
			l_spaceArray = null;

		if (r_pulseArray != null)
			r_pulseArray = null;

		if (r_spaceArray != null)
			r_spaceArray = null;

		if (mLPulseList.size()>0)
			mLPulseList.clear();

		if (mLSpaceList.size()>0)
			mLSpaceList.clear();

		if (mRPulseList.size()>0)
			mRPulseList.clear();

		if (mRSpaceList.size()>0)
			mRSpaceList.clear();
	}

//	public static void setStartLatch(int nCount)
//	{
//		if (start_latch == null)
//			start_latch = new CountDownLatch(nCount);
//		else if (start_latch.getCount() == 0)
//		{
//			start_latch = null;
//			start_latch = new CountDownLatch(nCount);
//		}
//	}

//	public static void setEndLatch(int nCount)
//	{
//		if (end_latch == null)
//			end_latch = new CountDownLatch(nCount);
//		else if (end_latch.getCount() <= 0)
//		{
//			end_latch = null;
//			end_latch = new CountDownLatch(nCount);
//		}
//	}

	public void setRunloop(float fLoop)
	{
		if (fLoop == 0.0f)
			misbLoop = true;
		else
			misbLoop = false;

		mLoopCount = (int)(fLoop*2f);
	}

	public boolean setLorRChannl(int r)
	{
		audioTrackF.setStereoVolume(7f, 7f);

//		mLorR = r;
//		if (r == 0) {
//			if (audioTrackF != null)
//				audioTrackF.setStereoVolume(3.5f, 0.0f);// 设置左右声道音量
//			else
//				return false;
//		}else if (r == 1) {
//			if (audioTrackF != null)
//				audioTrackF.setStereoVolume(0.0f, 3.5f);
//			else
//				return false;
//		}else {
//			if (audioTrackF != null)
//				audioTrackF.setStereoVolume(3.5f, 3.5f);
//			else
//				return false;
//		}

		return true;
	}

	public int getLorRChannl()
	{
		if (mLorR == 2)
			return 0;
		if (mLorR == 3)
			return 1;

		return mLorR;
	}

	public void setVolumeValue(Context context)
	{
		AudioManager am =(AudioManager)context.getSystemService(Context.AUDIO_SERVICE);
		int maxVolume = am.getStreamMaxVolume(AudioManager.STREAM_SYSTEM);
		//int currentVolume = am.getStreamVolume(AudioManager.STREAM_VOICE_CALL);//得到听筒模式的当前值

		am.adjustStreamVolume(AudioManager.STREAM_SYSTEM
				, AudioManager.ADJUST_RAISE, AudioManager.FLAG_PLAY_SOUND) ;

//		am.setStreamVolume(AudioManager.STREAM_RING, am.getStreamMaxVolume(AudioManager.STREAM_RING), AudioManager.ADJUST_RAISE);
//		am.setStreamVolume(AudioManager.STREAM_ALARM, am.getStreamMaxVolume(AudioManager.STREAM_ALARM), AudioManager.ADJUST_RAISE);
//		am.setStreamVolume(AudioManager.STREAM_NOTIFICATION, am.getStreamMaxVolume(AudioManager.STREAM_NOTIFICATION), AudioManager.ADJUST_RAISE);
//		am.setStreamVolume(AudioManager.STREAM_SYSTEM, am.getStreamMaxVolume(AudioManager.STREAM_SYSTEM), AudioManager.ADJUST_RAISE);
//		am.setStreamVolume(AudioManager.STREAM_DTMF, am.getStreamMaxVolume(AudioManager.STREAM_DTMF), AudioManager.ADJUST_RAISE);
//		am.setStreamVolume(AudioManager.STREAM_VOICE_CALL, am.getStreamMaxVolume(AudioManager.STREAM_VOICE_CALL), AudioManager.ADJUST_RAISE);
//		am.setStreamVolume(AudioManager.STREAM_MUSIC, am.getStreamMaxVolume
//				(AudioManager.STREAM_MUSIC), AudioManager.ADJUST_RAISE);
//
//		int currentVolume = am.getStreamVolume(AudioManager.STREAM_VOICE_CALL);//得到听筒模式的当前值
//		System.out.println("maxVolume  : " + maxVolume + " currentVolume : " +currentVolume);
	}

	public void setFreqHz(int nLHZ, int nRHZ)
	{
		mLFreqHz = nLHZ;
		mRFreqHz = nRHZ;
	}

	public void setFch(int nLHorL, int nRHorL)
	{
		mLHorL = nLHorL;
		mRHorL = nRHorL;
	}

	public void setSampleRateInHz(int nSampleRate)
	{
		sampleRateInHz = nSampleRate;
	}

	public void setFpsi(int nLFpsi, int nRFpsi)
	{
		mLFpsi = nLFpsi;
		mRFpsi = nRFpsi;
	}

	public void setAmp(int nLAmp, int nRAmp)
	{
		curr_L_iAmp = (float)nLAmp;
		curr_R_iAmp = (float)nRAmp;
	}

	void leftPstd(double bpms)
	{
		if(l_pulseArray != null) {
			for (int i = 0; i < l_pulseArray.length; i++) {
				float seed = l_pulseArray[i];

				if (seed < 0.02f)
					seed = 0.02f;
				else if(seed > 50f)
					seed = 50f;

				if (seed == 0.02f)
					l_pulseArray[i] = 1;
				else
					l_pulseArray[i] = (float) (seed * bpms) / 32;
			}
		}

		if(l_spaceArray != null) {
			for (int i = 0; i < l_spaceArray.length; i++) {
				float seed = l_spaceArray[i];

				if (seed < 0.02f)
					seed = 0.02f;
				else if(seed > 200f)
					seed = 200f;

				if (seed == 0.02f)
					l_spaceArray[i] = 1;
				else
					l_spaceArray[i] = (float) (seed * bpms) / 32;
			}
		}
	}

	void rightPstd(double bpms)
	{
		if(r_pulseArray != null) {
			for (int i = 0; i < r_pulseArray.length; i++) {
				float seed = r_pulseArray[i];

				if (seed < 0.02f)
					seed = 0.02f;
				else if(seed > 50f)
					seed = 50f;

				if (seed == 0.02f)
					r_pulseArray[i] = 1;
				else
					r_pulseArray[i] = (float) (seed * bpms) / 32;
			}
		}

		if(r_spaceArray != null) {
			for (int i = 0; i < r_spaceArray.length; i++) {
				float seed = r_spaceArray[i];

				if (seed < 0.02f)
					seed = 0.02f;
				else if(seed > 200f)
					seed = 200f;

				if (seed == 0.02f)
					r_spaceArray[i] = 1;
				else
					r_spaceArray[i] = (float) (seed * bpms) / 32;
			}
		}
	}

	public void setPstd(com.facebook.react.bridge.ReadableArray nLPstd, com.facebook.react.bridge.ReadableArray nRPstd)
	{
		//mPstd = nPstd;
		int nLPstdCount = nLPstd.size();
		mLPstd = nLPstdCount;

		int nRPstdCount = nRPstd.size();
		mRPstd = nRPstdCount;

		// 音频的码率=采样率（44.1k）*位深度（16）*通道数（2）=1411.2kbps
		double bpms = (double)sampleRateInHz*mSampBit*8*1/1000.0;// 705.6
		float step = (float)1000/sampleRateInHz;//毫秒

		DecimalFormat formater = new DecimalFormat("#0.###");
		formater.setRoundingMode(RoundingMode.FLOOR);
		step = Float.parseFloat(formater.format(step));

		float stepPulseCount = 50f;//(int)((float)(50-0.1)/step);//2268  2269
		float stepSpaceCount = 200f;//(int)((float)(200-0.1)/step);//9086

		if (nLPstdCount%2 == 0) {
			l_pulseArray = new float[nLPstdCount/2];
			l_spaceArray = new float[nLPstdCount/2];

		}else
		{
			if (mLFpsi==0)//1 Pulse, 0 Space
			{
				if (nLPstdCount == 1)
				{
					l_spaceArray = new float[nLPstdCount];
				}
				else
				{
					l_pulseArray = new float[nLPstdCount / 2];
					l_spaceArray = new float[nLPstdCount / 2 + 1];
				}
			}else
			{
				if (nLPstdCount == 1)
				{
					l_pulseArray = new float[nLPstdCount];
				}
				else
				{
					l_pulseArray = new float[nLPstdCount / 2 + 1];
					l_spaceArray = new float[nLPstdCount / 2];
				}
			}
		}

		int s = 0;
		int p = 0;
		for(int i=0;i<nLPstdCount;i++)
		{
			if (mLFpsi==0)//1 Pulse, 0 Space
			{
				float number = 0;
				String strNumber = nLPstd.getString(i);
				number = Float.parseFloat(strNumber);

				if (number < 0.02f)
					number = 0.02f;

				if (i%2 == 0) {
					if (number > stepSpaceCount)
						number = stepSpaceCount;

					l_spaceArray[s] = number;
					s++;
				}
				else {
					if (number > stepPulseCount)
						number = stepPulseCount;

					l_pulseArray[p] = number;
					p++;
				}

			}else
			{
				float number = 0;
				String strNumber = nLPstd.getString(i);
				number = Float.parseFloat(strNumber);

				if (number < 0.02f)
					number = 0.02f;

				if (i%2 == 0) {
					if (number > stepPulseCount)
						number = stepPulseCount;

					l_pulseArray[p] = number;
					p++;
				}else {
					if (number > stepSpaceCount)
						number = stepSpaceCount;

					l_spaceArray[s] = number;
					s++;
				}
			}
		}

		if (nRPstdCount%2 == 0) {
			r_pulseArray = new float[nRPstdCount/2];
			r_spaceArray = new float[nRPstdCount/2];

		}else
		{
			if (mRFpsi==0)//1 Pulse, 0 Space
			{
				if (nRPstdCount == 1)
				{
					r_spaceArray = new float[nRPstdCount];
				}
				else
				{
					r_pulseArray = new float[nRPstdCount / 2];
					r_spaceArray = new float[nRPstdCount / 2 + 1];
				}
			}else
			{
				if (nRPstdCount == 1)
				{
					r_pulseArray = new float[nRPstdCount];
				}
				else
				{
					r_pulseArray = new float[nRPstdCount / 2 + 1];
					r_spaceArray = new float[nRPstdCount / 2];
				}
			}
		}

		s = 0;
		p = 0;
		for(int i=0;i<nRPstdCount;i++)
		{
			if (mRFpsi==0)//1 Pulse, 0 Space
			{
				float number = 0;
				String strNumber = nRPstd.getString(i);
				number = Float.parseFloat(strNumber);

				if (number < 0.02f)
					number = 0.02f;

				if (i%2 == 0) {
					if (number > stepSpaceCount)
						number = stepSpaceCount;

					r_spaceArray[s] = number;
					s++;
				}
				else {
					if (number > stepPulseCount)
						number = stepPulseCount;

					r_pulseArray[p] = number;
					p++;
				}

			}else
			{
				float number = 0;
				String strNumber = nRPstd.getString(i);
				number = Float.parseFloat(strNumber);

				if (number < 0.02f)
					number = 0.02f;

				if (i%2 == 0) {
					if (number > stepPulseCount)
						number = stepPulseCount;

					r_pulseArray[p] = number;
					p++;
				}else {
					if (number > stepSpaceCount)
						number = stepSpaceCount;

					r_spaceArray[s] = number;
					s++;
				}
			}
		}

		leftPstd(bpms);
		rightPstd(bpms);
	}

	public void leftByteData()
	{
		//bufferSize = bufferSize * 2;
		m_i️SquareWave = sampleRateInHz/mLFreqHz/2;
		//System.out.println("!@#$%^&*()   m_i️SquareWave  : " + m_i️SquareWave);

		String bitdata = "";
		if (mLoopCount > 0) {
			for (int i = 0; i < mLoopCount; i++) {
				if (mLHorL == 1) {
					if (i%2 == 0)
						bitdata += "1";
					else
						bitdata += "0";
				} else {
					if (i%2 == 0)
						bitdata += "0";
					else
						bitdata += "1";
				}
			}
		}else {
			if (mLHorL == 1) {
				bitdata += "10";
			} else {
				bitdata += "01";
			}
		}

		this.m_data = bitdata;//result.toString();
		this.m_lenght = bitdata.length();
		//System.out.println("bitdata   : "+bitdata);

		m_L_bitDateF = null;

		m_L_bitDateF = getShortData(curr_L_iAmp);

//		System.out.println("m_bitDateF.length : "+m_bitDateF.length);
//
		for (int i=0;i<m_L_bitDateF.length;i++)
			System.out.println("m_L_bitDateF :  "+m_L_bitDateF[i]);
	}

	public void rightByteData()
	{
		//bufferSize = bufferSize * 2;
		m_i️SquareWave = sampleRateInHz/mRFreqHz/2;
		//System.out.println("!@#$%^&*()   m_i️SquareWave  : " + m_i️SquareWave);

		String bitdata = "";
		if (mLoopCount > 0) {
			for (int i = 0; i < mLoopCount; i++) {
				if (mRHorL == 1) {
					if (i%2 == 0)
						bitdata += "1";
					else
						bitdata += "0";
				} else {
					if (i%2 == 0)
						bitdata += "0";
					else
						bitdata += "1";
				}
			}
		}else {
			if (mRHorL == 1) {
				bitdata += "10";
			} else {
				bitdata += "01";
			}
		}

		this.m_data = bitdata;//result.toString();
		this.m_lenght = bitdata.length();
		//System.out.println("bitdata   : "+bitdata);

		m_R_bitDateF = null;

		m_R_bitDateF = getShortData(curr_R_iAmp);

//		System.out.println("m_bitDateF.length : "+m_bitDateF.length);
//
		for (int i=0;i<m_R_bitDateF.length;i++)
			System.out.println("m_R_bitDateF :  "+m_R_bitDateF[i]);
	}

	public void sendByteData(){//(byte[] byteData, int len){

		//closeAudioTrack();
		if (audioTrackF == null)
			initAudioTrack();

		audioTrackF.flush();

		leftByteData();
		rightByteData();

		m_bitDateF = null;

		int bufferSize = AudioTrack.getMinBufferSize(sampleRateInHz, mChannel,
				mSampBit);

		int count = 0;
		float m_TDateF[] = null;
			if (m_L_bitDateF != null && m_R_bitDateF != null)
			{
				if (m_L_bitDateF.length < m_R_bitDateF.length)
					count = m_R_bitDateF.length;
				else
					count = m_L_bitDateF.length;

				m_TDateF = new float[count*2];
				for (int i=0,j=0;i<count;i++)
				{
					if (i < m_L_bitDateF.length)
					{
						m_TDateF[j] = m_L_bitDateF[i];
					}else
					{
						m_TDateF[j] = m_L_bitDateF[i%m_L_bitDateF.length];
						nLeftPos = i%m_L_bitDateF.length;
					}

					if (i < m_R_bitDateF.length)
					{
						m_TDateF[j+1] = m_R_bitDateF[i];
					}else
					{
						m_TDateF[j+1] = m_R_bitDateF[i%m_R_bitDateF.length];
						nRightPos = i%m_R_bitDateF.length;
					}
					j+=2;
				}
			}else
				return;

		if (!misbLoop) {
			if (count*2 < bufferSize) {
				m_bitDateF = new float[bufferSize];
			}else
				m_bitDateF = new float[count*2];

			for (int i = 0; i < m_bitDateF.length; i++)
				m_bitDateF[i] = (float) 0.0f;
			System.arraycopy(m_TDateF, 0, m_bitDateF, 0, m_TDateF.length);
			//System.out.println("_ _ _ _ _ m_bitDateF.length : " + m_bitDateF.length);
		}else
		{
			m_bitDateF = new float[m_TDateF.length];
			System.arraycopy(m_TDateF, 0, m_bitDateF, 0, m_TDateF.length);
		}

		if (audioTrackThread == null) {
			//AudioWaveOut.setEndLatch(2);
			audioTrackThread = new AudioTrackFThread();
			audioTrackThread.start();
			audioTrackF.play();
		}else
		{

			synchronized (audioTrackThread) {
				//System.out.println(modelName+" synchronized (audioTrackThread)");
				if (audioTrackF != null)
					audioTrackF.play();
				audioTrackThread.notify();
				//System.out.println(modelName+" audioTrackF play");
			}
		}

	}

	public static void i(String tag, String msg) {  //信息太长,分段打印
		//因为String的length是字符数量不是字节数量所以为了防止中文字符过多，
		//  把4*1024的MAX字节打印长度改为2001字符数
		int max_str_length = 2001 - tag.length();
		//大于4000时
		while (msg.length() > max_str_length) {
			Log.i(tag, msg.substring(0, max_str_length));
			msg = msg.substring(max_str_length);
		}
		//剩余部分
		Log.i(tag, msg);
	}

	float[] leftSpacePulseData()
	{
		//bufferSize = bufferSize * 2;
		mLFreqHz = 1000;

		m_i️SquareWave = sampleRateInHz/mLFreqHz/2;
		//System.out.println("m_i️SquareWave : "+ m_i️SquareWave+" sampleRateInHz : "+sampleRateInHz+" mFreqHz : "+mFreqHz);

//		String bitdata = "";
//		if (mLoopCount > 0) {
//			for (int i = 0; i < mLoopCount; i++) {
//				if (mHorL == 1) {
//					bitdata += "10";
//				} else {
//					bitdata += "01";
//				}
//			}
//		}else {
//			if (mHorL == 1) {
//				bitdata += "10";
//			} else {
//				bitdata += "01";
//			}
//		}
//
//		this.m_data = bitdata;//result.toString();
//		this.m_lenght = bitdata.length();
//		System.out.println("bitdata   : "+bitdata);
//
//		this.m_data = byteData;
//		this.m_lenght = len;


		mLSpaceCount = getSpaceData(curr_L_iAmp, l_spaceArray, mLSpaceList);
		mLPulseCount = getPulseData(curr_L_iAmp, l_pulseArray, mLPulseList);

		int flat_count = 0;//100;
		float left_data[] = null;
		if (mLSpaceCount + mLPulseCount <=0)
			return null;
		else
			left_data = new float[mLSpaceCount + mLPulseCount];

		// 1 pulse  0 space
		if (mLFpsi == 0)
		{
			if (mLPstd == 1)
			{
				float tempSpace[] = (float[]) mLSpaceList.get(0);
//				for (int i=0;i<tempSpace.length;i++)
//					m_bitDateF[flat_count + i] = tempSpace[i];
				System.arraycopy(tempSpace, 0, left_data, 0, tempSpace.length);
				//System.out.println("Pulse is this first :    mSpaceCount : "+mSpaceCount+"    mPulseCount : "+mPulseCount+"  tempSpace.length : "+tempSpace.length);

			}else {
				int i = 0;
				int count = flat_count;
				for (; i < mLPstd / 2; i++) {
					float tempSpace[] = (float[]) mLSpaceList.get(i);
					float tempPulse[] = (float[]) mLPulseList.get(i);
//					for (int t=0;t<tempSpace.length;t++)
//						m_bitDateF[count+t] = tempSpace[t];
					System.arraycopy(tempSpace, 0, left_data, count, tempSpace.length);
					System.arraycopy(tempPulse, 0, left_data, count + tempSpace.length, tempPulse.length);

					count = count + tempPulse.length + tempSpace.length;
				}

				if (mLSpaceList.size() > mLPulseList.size()) {
					float tempSpace[] = (float[]) mLSpaceList.get(i);
//					for (int t=0;t<tempSpace.length;t++)
//						m_bitDateF[count+t] = tempSpace[t];
					System.arraycopy(tempSpace, 0, left_data, count, tempSpace.length);
				} else if (mLSpaceList.size() < mLPulseList.size()) {
					float tempPulse[] = (float[]) mLPulseList.get(i);
					System.arraycopy(tempPulse, 0, left_data, count, tempPulse.length);
				}
			}
		}else
		{
			if (mLPstd == 1)
			{
				float tempPulse[] = (float[]) mLPulseList.get(0);
//				for (int i=0;i<tempPulse.length;i++)
//					m_bitDateF[flat_count+i] = tempPulse[i];
				System.arraycopy(tempPulse, 0, left_data, 0, tempPulse.length);
				//System.out.println("Pulse is this first :    mSpaceCount : "+mSpaceCount+"    mPulseCount : "+mPulseCount+"  tempPulse.length : "+tempPulse.length);

			}else {
				int i = 0;
				int count = flat_count;
				for (; i < mLPstd / 2; i++) {
					float tempSpace[] = (float[]) mLSpaceList.get(i);
					float tempPulse[] = (float[]) mLPulseList.get(i);

					System.out.println("tempSpace length  : "+tempSpace.length);
					System.out.println("tempPulse length  : "+tempPulse.length);
					System.arraycopy(tempPulse, 0, left_data, count, tempPulse.length);
					//Log.i("flag", "count : "+m_bitDateF.length+" pulse length:  "+tempPulse.length);

					System.arraycopy(tempSpace, 0, left_data, count + tempPulse.length, tempSpace.length);
					//Log.i("flag", "count : "+m_bitDateF.length+" space length:  "+tempSpace.length);
//					for (int t=0;t<tempSpace.length;t++)
//						m_bitDateF[count + tempPulse.length + t] = tempSpace[t];

					count = count + tempPulse.length + tempSpace.length;
					//System.out.println("count : "+count+"    mPstd / 2 : "+mPstd / 2 + "   i :"+i);
				}

				if (mLSpaceList.size() > mLPulseList.size()) {
					float tempSpace[] = (float[]) mLSpaceList.get(i);
					System.arraycopy(tempSpace, 0, left_data, count, tempSpace.length);
					//Log.i("flag", "count : "+m_bitDateF.length);
//					for (int t=0;t<tempSpace.length;t++)
//						m_bitDateF[count + t] = tempSpace[t];
				} else if (mLSpaceList.size() < mLPulseList.size()) {
					float tempPulse[] = (float[]) mLPulseList.get(i);
					System.arraycopy(tempPulse, 0, left_data, count, tempPulse.length);
					//Log.i("flag", "count : "+m_bitDateF.length);
					//System.out.println("mPulseList.size() : "+mPulseList.size()+"     mSpaceList.size() : "+mSpaceList.size());
				}
			}
		}

//		String str = "";
//		for (int i=0;i<(mSpaceCount + mPulseCount);i++)
//		{
//			str = str + "~~~~m_bitDateF[i] : "+m_bitDateF[i]+" i :"+i+"\n";
//		}
//
//		AudioWaveOut.i("flag", str);
//		//Log.i("flag", str);
//		Log.i("flag", "mSpaceCount + mPulseCount : "+(mSpaceCount + mPulseCount));

//		System.out.println("m_bitDateF.length :    "+m_bitDateF.length+" mSpaceCount  :"+ mSpaceCount + " mPulseCount  :"+mPulseCount);

		return  left_data;
	}

	float[] rightSpacePulseData()
	{
		mLFreqHz = 1000;

		m_i️SquareWave = sampleRateInHz/mRFreqHz/2;
		//System.out.println("m_i️SquareWave : "+ m_i️SquareWave+" sampleRateInHz : "+sampleRateInHz+" mFreqHz : "+mFreqHz);

//		String bitdata = "";
//		if (mLoopCount > 0) {
//			for (int i = 0; i < mLoopCount; i++) {
//				if (mHorL == 1) {
//					bitdata += "10";
//				} else {
//					bitdata += "01";
//				}
//			}
//		}else {
//			if (mHorL == 1) {
//				bitdata += "10";
//			} else {
//				bitdata += "01";
//			}
//		}
//
//		this.m_data = bitdata;//result.toString();
//		this.m_lenght = bitdata.length();
//		System.out.println("bitdata   : "+bitdata);
//
//		this.m_data = byteData;
//		this.m_lenght = len;


		mRSpaceCount = getSpaceData(curr_R_iAmp, r_spaceArray, mRSpaceList);
		mRPulseCount = getPulseData(curr_R_iAmp, r_pulseArray, mRPulseList);

		float right_data[] = null;
		if (mRSpaceCount + mRPulseCount <=0)
			return null;
		else
			right_data = new float[mRSpaceCount + mRPulseCount];

		int flat_count = 0;//100;
		// 1 pulse  0 space
		if (mRFpsi == 0)
		{
			if (mRPstd == 1)
			{
				float tempSpace[] = (float[]) mRSpaceList.get(0);
//				for (int i=0;i<tempSpace.length;i++)
//					m_bitDateF[flat_count + i] = tempSpace[i];
				System.arraycopy(tempSpace, 0, right_data, 0, tempSpace.length);
				//System.out.println("Pulse is this first :    mSpaceCount : "+mSpaceCount+"    mPulseCount : "+mPulseCount+"  tempSpace.length : "+tempSpace.length);

			}else {
				int i = 0;
				int count = flat_count;
				for (; i < mRPstd / 2; i++) {
					float tempSpace[] = (float[]) mRSpaceList.get(i);
					float tempPulse[] = (float[]) mRPulseList.get(i);
//					for (int t=0;t<tempSpace.length;t++)
//						m_bitDateF[count+t] = tempSpace[t];
					System.arraycopy(tempSpace, 0, right_data, count, tempSpace.length);
					System.arraycopy(tempPulse, 0, right_data, count + tempSpace.length, tempPulse.length);

					count = count + tempPulse.length + tempSpace.length;
				}

				if (mRSpaceList.size() > mRPulseList.size()) {
					float tempSpace[] = (float[]) mRSpaceList.get(i);
//					for (int t=0;t<tempSpace.length;t++)
//						m_bitDateF[count+t] = tempSpace[t];
					System.arraycopy(tempSpace, 0, right_data, count, tempSpace.length);
				} else if (mRSpaceList.size() < mRPulseList.size()) {
					float tempPulse[] = (float[]) mRPulseList.get(i);
					System.arraycopy(tempPulse, 0, right_data, count, tempPulse.length);
				}
			}
		}else
		{
			if (mRPstd == 1)
			{
				float tempPulse[] = (float[]) mRPulseList.get(0);
//				for (int i=0;i<tempPulse.length;i++)
//					m_bitDateF[flat_count+i] = tempPulse[i];
				System.arraycopy(tempPulse, 0, right_data, 0, tempPulse.length);
				//System.out.println("Pulse is this first :    mSpaceCount : "+mSpaceCount+"    mPulseCount : "+mPulseCount+"  tempPulse.length : "+tempPulse.length);

			}else {
				int i = 0;
				int count = flat_count;
				for (; i < mRPstd / 2; i++) {
					float tempSpace[] = (float[]) mRSpaceList.get(i);
					float tempPulse[] = (float[]) mRPulseList.get(i);

					System.arraycopy(tempPulse, 0, right_data, count, tempPulse.length);
					//Log.i("flag", "count : "+m_bitDateF.length+" pulse length:  "+tempPulse.length);

					System.arraycopy(tempSpace, 0, right_data, count + tempPulse.length, tempSpace.length);
					//Log.i("flag", "count : "+m_bitDateF.length+" space length:  "+tempSpace.length);
//					for (int t=0;t<tempSpace.length;t++)
//						m_bitDateF[count + tempPulse.length + t] = tempSpace[t];

					count = count + tempPulse.length + tempSpace.length;
					//System.out.println("count : "+count+"    mPstd / 2 : "+mPstd / 2 + "   i :"+i);
				}

				if (mRSpaceList.size() > mRPulseList.size()) {
					float tempSpace[] = (float[]) mRSpaceList.get(i);
					System.arraycopy(tempSpace, 0, right_data, count, tempSpace.length);
					//Log.i("flag", "count : "+m_bitDateF.length);
//					for (int t=0;t<tempSpace.length;t++)
//						m_bitDateF[count + t] = tempSpace[t];
				} else if (mRSpaceList.size() < mRPulseList.size()) {
					float tempPulse[] = (float[]) mRPulseList.get(i);
					System.arraycopy(tempPulse, 0, right_data, count, tempPulse.length);
					//Log.i("flag", "count : "+m_bitDateF.length);
					//System.out.println("mPulseList.size() : "+mPulseList.size()+"     mSpaceList.size() : "+mSpaceList.size());
				}
			}
		}

//		String str = "";
//		for (int i=0;i<(mSpaceCount + mPulseCount);i++)
//		{
//			str = str + "~~~~m_bitDateF[i] : "+m_bitDateF[i]+" i :"+i+"\n";
//		}
//
//		AudioWaveOut.i("flag", str);
//		//Log.i("flag", str);
//		Log.i("flag", "mSpaceCount + mPulseCount : "+(mSpaceCount + mPulseCount));

//		System.out.println("m_bitDateF.length :    "+m_bitDateF.length+" mSpaceCount  :"+ mSpaceCount + " mPulseCount  :"+mPulseCount);
		return right_data;
	}

	public void sendSpacePulseByteData()//byte[] byteData, int len)
	{
		if (audioTrackF == null)
			initAudioTrack();

		float leftData[] = leftSpacePulseData();
		float rightData[] = rightSpacePulseData();

		//System.out.println("leftData.length :    "+leftData.length+"    rightData.length :"+ rightData.length);

		if (leftData != null && rightData != null)
		{
			int bufferSize = AudioTrack.getMinBufferSize(sampleRateInHz, mChannel,
				mSampBit);

			m_bitDateF = null;

			if ((leftData.length + rightData.length) > bufferSize) {
				m_bitDateF = new float[leftData.length + rightData.length];
			}else
				m_bitDateF = new float[bufferSize];

			for (int i =0;i<m_bitDateF.length;i++)
				m_bitDateF[i] = (float)0.0f;

			int count = 0;
			if (leftData.length < rightData.length)
				count = rightData.length;
			else
				count = leftData.length;

			for (int i=0,j=0;i<count;i++)
			{
				if (i < leftData.length)
				{
					m_bitDateF[j] = leftData[i];
				}else
				{
					m_bitDateF[j] = 0;
				}

				if (i < rightData.length)
				{
					m_bitDateF[j+1] = rightData[i];
				}else
				{
					m_bitDateF[j+1] = 0;
				}
				j+=2;
			}
		}else
			return;

		setRunloop(1);

		if (audioTrackThread == null) {
			//AudioWaveOut.setEndLatch(2);
			audioTrackThread = new AudioTrackFThread();
			audioTrackThread.start();
			audioTrackF.play();
		}else
		{
			synchronized (audioTrackThread) {

				//System.out.println("notify");
				if (audioTrackF != null)
					audioTrackF.play();
				audioTrackThread.notify();
			}
		}
	}


	private int getPulseData(float curr_iAmp, float[] pulseArray, ArrayList mPulseList)
	{
		if (pulseArray == null)
			return 0;

		final float order = 25;
		final float min_order = min_iAmp/order;
		final float max_order = max_iAmp/order;

		int mPulseCount = 0;

		for (int k=0;k<pulseArray.length;k++)
		{
			int j = 0;
//			if (k%2 == 0)
//				strBinary = "1";
//			else
//				strBinary = "0";

//			String strFBinary = strBinary;

			//int m_iSquareWave_1 = 0;
			int m_iSW = (int)pulseArray[k];//m_i️SquareWave;
			//System.out.println("m_iSW :  "+m_iSW+" i : "+k);

//			int _len = 0;
//			_len = (int) (pulseArray[k] / m_i️SquareWave);
//
//			if (_len < 1) {
//				_len = 1;
//				m_iSW = (int) pulseArray[k];
//			} else if (_len > len) {
//				//原长度不够，加一串数据到_len长度
//				int __len = _len - len;
//				do {
//					String substr = "";
//					if (__len > len) {
//						substr = strBinary.substring(0, len);
//						__len = __len - len;
//					} else {
//						substr = strBinary.substring(0, __len);
//						__len = 0;
//					}
//
//					strFBinary.concat(substr);// 拼接
//				} while (__len > len);
//
//				String substr = "";
//				substr = strBinary.substring(0, __len);
//				strFBinary.concat(substr);// 拼接
//
//				m_iSquareWave_1 = (int) (pulseArray[k] - _len * m_iSquareWave_1);
//			}

			int m_bitDateSize = m_iSW;//(int) (_len * m_iSW + m_iSquareWave_1);//m_i️SquareWave;
			float m_pPulseDate[] = new float[m_bitDateSize];

			//for (int i = 0; i < _len; i++) {
				int ct = m_iSW;
//				if (mFpsi == 1) {
//					if (strFBinary.charAt(0) == '1') {
						while (ct-- > 0) {
							if (curr_iAmp == 25) {
								m_pPulseDate[j++] = max_iAmp;//min_iAmp;
								//System.out.println("max_iAmp : "+max_iAmp);
							}else
								m_pPulseDate[j++] = (float)(max_order * curr_iAmp);//(float) (min_order * curr_iAmp);//min_iAmp;
						}
//					}
//					else {
//						while (ct-- > 0) {
//							if (curr_iAmp == 25)
//								m_pPulseDate[j++] = min_iAmp;//max_iAmp;
//							else
//								m_pPulseDate[j++] = (float) (min_order * curr_iAmp);//max_iAmp;
//							//System.out.println("j:  "+j);
//						}
//					}
//				} else {
//					if (strFBinary.charAt(i) == '1') {
//						while (ct-- > 0) {
//							if (curr_iAmp == 25)
//								m_pPulseDate[j++] = max_iAmp;
//							else
//								m_pPulseDate[j++] = (float) (max_order * curr_iAmp);//min_iAmp;
//						}
//					} else {
//						while (ct-- > 0) {
//							if (curr_iAmp == 25)
//								m_pPulseDate[j++] = min_iAmp;
//							else
//								m_pPulseDate[j++] = (float) (min_order * curr_iAmp);//max_iAmp;
//						}
//					}
//				}
			//}

//			if (m_iSquareWave_1 > 0) {
//				int ct = m_iSquareWave_1;
//				if (mFpsi == 1) {
//					if (strFBinary.charAt(0) == '1') {
//						while (ct-- > 0) {
//							if (curr_iAmp == 25)
//								m_pPulseDate[j++] = min_iAmp;//min_iAmp;
//							else
//								m_pPulseDate[j++] = (float) (min_order * curr_iAmp);//min_iAmp;
//						}
//					} else {
//						while (ct-- > 0) {
//							if (curr_iAmp == 25)
//								m_pPulseDate[j++] = max_iAmp;
//							else
//								m_pPulseDate[j++] = (float) (max_order * curr_iAmp);//max_iAmp;
//						}
//					}
//				} else {
//					if (strFBinary.charAt(0) == '1') {
//						while (ct-- > 0) {
//							if (curr_iAmp == 25)
//								m_pPulseDate[j++] = max_iAmp;//min_iAmp;
//							else
//								m_pPulseDate[j++] = (float) (max_order * curr_iAmp);//min_iAmp;
//						}
//					} else {
//						while (ct-- > 0) {
//							if (curr_iAmp == 25)
//								m_pPulseDate[j++] = min_iAmp;
//							else
//								m_pPulseDate[j++] = (float) (min_order * curr_iAmp);//max_iAmp;
//						}
//					}
//				}
//			}

//			for (int i=0;i<j;i++)
//				System.out.println("m_pPulseDate[i]: "+m_pPulseDate[i]);

			//System.out.println("PulseData  m_bitDateSize: "+m_bitDateSize+"  j : " + j + "  m_iSW : "+ m_iSW);
			mPulseList.add(m_pPulseDate);
			mPulseCount+=m_bitDateSize;
		}

		return mPulseCount;
	}

	private int getSpaceData(float curr_iAmp, float spaceArray[], ArrayList mSpaceList)
	{
		if (spaceArray == null)
			return 0;

		final float order = 25;
		final float min_order = min_iAmp/order;
		final float max_order = max_iAmp/order;

		int mSpaceCount = 0;
		for (int k=0;k<spaceArray.length;k++)
		{
			int j = 0;
			int m_iSW = (int)spaceArray[k];//m_i️SquareWave;
			//System.out.println("SpaceData  m_iSW: "+m_iSW+"  k : " + k);

			//int m_i️SquareWave_1 = 0;
			//int len = (int) (spaceArray[k] / m_i️SquareWave);

//			if (len < 1) {
//				len = 1;
//				m_iSW = (int) spaceArray[k];
//			} else if (len > 1) {
//				m_i️SquareWave_1 = (int) (spaceArray[k] - len * m_i️SquareWave);
//			}

			int m_bitDateSize = m_iSW;//len * m_iSW + m_i️SquareWave_1;
			float[] m_pSpaceDate = new float[m_bitDateSize];

			int ct = m_iSW;

				while (ct-- > 0) {
					if (curr_iAmp == 25)
						m_pSpaceDate[j++] = min_iAmp;//max_iAmp;
					else
						m_pSpaceDate[j++] = (float) (min_order * curr_iAmp);//max_iAmp;
					//System.out.println("j:  "+j);
				}

			//for (int i = 0; i < len; i++) {
//				int ct = m_iSW;
//				while (ct-- > 0) {
//					m_pSpaceDate[j++] = (float) 0;
//				}
			//}
//			for (int i=0;i<j;i++)
//				System.out.println("m_pSpaceDate[i]: "+m_pSpaceDate[i]);


			//System.out.println("SpaceData  m_bitDateSize: "+m_bitDateSize+"  j : " + j + "  m_iSW : "+ m_iSW);

			mSpaceList.add(m_pSpaceDate);
			mSpaceCount+=m_bitDateSize;
		}

		return mSpaceCount;
	}

	// 通过byteDate转为short型的声音数据
	private float[] getShortData(float curr_iAmp)
	{
		int j = 0;
		int nWaveCount = m_i️SquareWave;
		String strBinary = this.m_data;//getstrBinary(this.m_data, this.m_lenght);
		int len = strBinary.length();
		int m_bitDateSize = len * m_i️SquareWave;
		float[] m_pDate = new float[m_bitDateSize];
		System.out.println("m_bitDateSize : "+m_bitDateSize);
		final float order = 25;
		final float min_order = (float)(min_iAmp/order);
		final float max_order = (float)(max_iAmp/order);

		//System.out.println("strBinary : "+strBinary+" len : "+len+" m_i️SquareWave : "+m_i️SquareWave+" m_bitDateSize : "+m_bitDateSize+"  curr_iAmp:  "+curr_iAmp+"  min_order : "+min_order+"   max_order"+max_order);
//String as_flag = "";
		for (int i = 0; i < len; i++)
		{
			int ct = nWaveCount;
//			if (mHorL == 1)
//			{
				if (strBinary.charAt(i) == '1')
				{

					while (ct-- > 0) {

						if (curr_iAmp == 25)
							m_pDate[j++] = max_iAmp;
						else
							m_pDate[j++] = (float)(max_order*curr_iAmp);
					}
				} else {

					while (ct-- > 0) {
						if (curr_iAmp == 25)
							m_pDate[j++] = min_iAmp;
						else
							m_pDate[j++] = (float)(min_order*curr_iAmp);
					}
				}
//			}else
//			{
//				if (strBinary.charAt(i) == '1') {
//					ct = nWaveCount;
//					while (ct-- > 0) {
//						if (curr_iAmp == 25)
//							m_pDate[j++] = max_iAmp;
//						else
//							m_pDate[j++] = (float)(max_order*curr_iAmp);//min_iAmp;
//
//						//System.out.println("1 + "+ct);
//					}
//				} else {
//					ct = nWaveCount;
//					while (ct-- > 0) {
//						if (curr_iAmp == 25)
//							m_pDate[j++] = min_iAmp;
//						else
//							m_pDate[j++] = (float)(min_order*curr_iAmp);//max_iAmp;
//
//						//System.out.println("0 - "+ct);
//					}
//				}
//			}
		}

//		int t=0;
//		//String tempAS = "";
//		for (t=0;t<m_pDate.length;t++) {
//			System.out.println("m_pDate :  " + m_pDate[t] + " j : " + j);
//			//tempAS += m_pDate[t]+"\r\n";
//		}
//
//		System.out.println("t :  "+t);

//		String filePath = "/sdcard/Download/";
//		String fileName = "m_pData_Test.txt";
//		writeTxtToFile(tempAS, filePath, fileName);
//
//		String filePath2 = "/sdcard/Download/";
//		String fileName2 = "m_pData_Flag.txt";
//		writeTxtToFile(as_flag, filePath2, fileName2);

		return m_pDate;
	}

	// 将一个字节编码转为2进制字符串
	private String getstrBinary(byte[] date, int lenght) {
		StringBuffer strDate = new StringBuffer(lenght * 8);
		for (int i = 0; i < lenght; i++) {
			String str = Integer.toBinaryString(date[i]);
//          System.out.println("str:"+str);
			// 长度不够，末尾填0
			while (str.length() < 8) {
				str = '0' + str;
			}
			strDate.append(str);
		}

		//System.out.println("strDate: "+strDate);
		return strDate.toString();
	}

	// 将字符串写入到文本文件中
	public void writeTxtToFile(String strcontent, String filePath, String fileName) {
		//生成文件夹之后，再生成文件，不然会出错
		makeFilePath(filePath, fileName);

		String strFilePath = filePath+fileName;
		// 每次写入时，都换行写
		String strContent = strcontent + "\r\n";
		try {
			File file = new File(strFilePath);
			if (!file.exists()) {
				Log.d("TestFile", "Create the file:" + strFilePath);
				file.getParentFile().mkdirs();
				file.createNewFile();
			}
			RandomAccessFile raf = new RandomAccessFile(file, "rwd");
			raf.seek(file.length());
			raf.write(strContent.getBytes());
			raf.close();
		} catch (Exception e) {
			Log.e("TestFile", "Error on write File:" + e);
		}
	}

	// 生成文件
	public File makeFilePath(String filePath, String fileName) {
		File file = null;
		makeRootDirectory(filePath);
		try {
			file = new File(filePath + fileName);
			if (!file.exists()) {
				file.createNewFile();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return file;
	}

	// 生成文件夹
	public static void makeRootDirectory(String filePath) {
		File file = null;
		try {
			file = new File(filePath);
			if (!file.exists()) {
				file.mkdir();
			}
		} catch (Exception e) {
			Log.i("error:", e+"");
		}
	}

	public synchronized void setCloseTime(double mTime)
	{
		mCloseTime = new BigDecimal(mTime/1000);// 毫秒
		//System.out.println(mCloseTime);

		// stepPulseCount  : 2268   stepSpaceCount  : 9086

//		String s = "1100,4500,";
//		int j =3;
//		for(int i=1;i<499;i++)
//		{
//			s += "1100,4500,";
//			j+=2;
//		}
//		s+="1100";
//
//		System.out.println(s);
//		System.out.println(" j : "+j);

//		if (audioTrackThread != null) {
//			synchronized (audioTrackThread) {
//
//				//System.out.println("notify");
//				audioTrackThread.notify();
//			}
//		}
	}

	public void setThreadLoop(boolean isbThreadLoop)
	{
		misbThreadLoop = isbThreadLoop;
	}

//		public synchronized void setTestCloseTime(long mTime)
//		{
//			mTestCloseTime = mTime;// 毫秒
//			System.out.println(mTestCloseTime);
//		}

	private float[] reData()
	{
		int count = 0;
		float m_TDateF[] = null;
		if (m_L_bitDateF != null && m_R_bitDateF != null)
		{
			if (m_L_bitDateF.length < m_R_bitDateF.length)
				count = m_R_bitDateF.length;
			else
				count = m_L_bitDateF.length;

			int lPos = 0;
			int rPos = 0;
			m_TDateF = new float[count*2];
			for (int i=0,j=0;i<count;i++)
			{
				if (i < m_L_bitDateF.length)
				{
					if (nLeftPos == 0)
						m_TDateF[j] = m_L_bitDateF[i];
					else
						m_TDateF[j] = m_L_bitDateF[(i+nLeftPos+1)%m_L_bitDateF.length];
				}else
				{
					m_TDateF[j] = m_L_bitDateF[(i+nLeftPos+1)%m_L_bitDateF.length];
					lPos = (i+nLeftPos+1)%m_L_bitDateF.length;
				}

				if (i < m_R_bitDateF.length)
				{
					if (nRightPos == 0)
						m_TDateF[j+1] = m_R_bitDateF[i];
					else
						m_TDateF[j+1] = m_R_bitDateF[(i+nRightPos+1)%m_R_bitDateF.length];
				}else
				{
					m_TDateF[j+1] = m_R_bitDateF[(i+nRightPos+1)%m_R_bitDateF.length];
					rPos = (i+nRightPos+1)%m_R_bitDateF.length;
				}
				j+=2;
			}

			nLeftPos = lPos;
			nRightPos = rPos;
		}else
			return null;


		return m_TDateF;
	}

	private void playWaveF(float[] mbitDateF) {

		if (audioTrackF == null) {
			System.out.println(modelName+" audioTrackF is null, return");
			return;
		}

		BigDecimal loopTime = new BigDecimal(0);
		long beginCloseTimeStart = 0;
		long endCloseTimeStart = 0;

		mDataWriteCount = 0;
		int bufferSize = AudioTrack.getMinBufferSize(sampleRateInHz, mChannel,
				mSampBit);

//		for (int i = 0; i < m_bitDateF.length; i++)
//			System.out.println("mbitDateF[i] : "+mbitDateF[i]);

		while(misbLoop || mLoopCount>0) {
			long start = 0;
			long end = 0;
			endCloseTimeStart = 0;

			if (loopTime.compareTo(mCloseTime) == -1 && beginCloseTimeStart == 0) {
				beginCloseTimeStart = System.nanoTime();//纳秒
			}else if(loopTime.compareTo(mCloseTime) == 0)
			{
//				misbLoop = false;
//				setCloseTime(-1);
//				audioTrackF.flush();
				//setTestCloseTime(System.nanoTime());
				//System.out.println("退出");
				break;
			}

			if (beginCloseTimeStart > 0)
				start = System.nanoTime();//纳秒
			//System.out.println(start);


//			for (int i=0;i<m_bitDateF.length;i++)
//				System.out.println("~~~~~ m_bitDateF :  "+mbitDateF[i]);

				if (mbitDateF != null && mbitDateF.length > 0) {
					if (mbitDateF.length > bufferSize) {
						if (mDataWriteCount < mbitDateF.length) {
							int dataCount = bufferSize;
							if ((mbitDateF.length - mDataWriteCount) < dataCount)
								dataCount = mbitDateF.length - mDataWriteCount;
							int afw = audioTrackF.write(mbitDateF, mDataWriteCount, dataCount, AudioTrack.WRITE_BLOCKING);// 该方法是阻塞的
							//System.out.println("大 audioTrackF.write      mbitDateF.length : " + mbitDateF.length + "   afw : " + afw + " dataCount :"+ dataCount+" mDataWriteCount: "+mDataWriteCount);
							mDataWriteCount += afw;
						} else {
//							int afw = audioTrackF.write(mbitDateF, mDataWriteCount, mbitDateF.length - mDataWriteCount);// 该方法是阻塞的
//							System.out.println("大End audioTrackF.write      mbitDateF.length : " + mbitDateF.length + "   afw : " + afw);
							mDataWriteCount = 0;
							if (mLoopCount>0)
							{
								break;
							}else
							{
								mbitDateF = null;
								mbitDateF = reData();
							}
							//mLoopCount--;

							//System.out.println("mbitDateF  mLoopCount :  "+mLoopCount);
						}
					} else {
						int afw = audioTrackF.write(mbitDateF, 0, mbitDateF.length, AudioTrack.WRITE_BLOCKING);
						//System.out.println("小 audioTrackF.write      mbitDateF.length : " + mbitDateF.length + "   afw : " + afw);
						//audioTrackF.flush();
						if (mLoopCount>0)
						{
							break;
						}else
						{
							mbitDateF = null;
							mbitDateF = reData();
						}
						//mLoopCount--;

						//ystem.out.println("mbitDateF  mLoopCount :  "+mLoopCount);
					}
				} else {
					//System.out.println("mbitDateF is null!!");
				}


			if (beginCloseTimeStart>0) {
				end = System.nanoTime();//纳秒
				//System.out.println(end);

				BigDecimal diff = BigDecimal.valueOf(end - start, 10);//秒级差值
				//System.out.println(diff);

				BigDecimal result = diff.setScale(9, RoundingMode.HALF_UP);//调节精度
				//System.out.println(result);

				endCloseTimeStart = System.nanoTime();//纳秒
				BigDecimal _diff = BigDecimal.valueOf(endCloseTimeStart - beginCloseTimeStart, 10);//秒级差值
				BigDecimal _result = _diff.setScale(9, RoundingMode.HALF_UP);//调节精度
				BigDecimal time_consuming = _result.add(result);

				//System.out.println(time_consuming);
				//System.out.println(mCloseTime);

				if (mCloseTime.compareTo(time_consuming) == -1) {
					misbLoop = false;
					setCloseTime(-1);
					audioTrackF.flush();
					//setTestCloseTime(System.nanoTime());
					//System.out.println("退出");
					break;
				}
			}


			//java.text.DecimalFormat fmt = new DecimalFormat("#.#########s");//输出格式化
			//System.out.println(fmt.format(result));
		}

		misbLoop = false;
		setCloseTime(-1);
		audioTrackF.flush();
		//System.out.println("closeAudioTrack");
		closeAudioTrack();
	}

	public void closeAudioTrack(){
		if(audioTrackF != null){
			//audioTrackF.pause();
			audioTrackF.stop();
			audioTrackF.release();
			audioTrackF = null;
			//System.out.println("closeAudioTrack() is finished");

			//System.out.println(modelName+" audio track is closed");
		}
	}

	class AudioTrackFThread extends Thread{
		@Override
		public void run() {
			while(misbThreadLoop) {
					//System.out.println(mTestCloseTime);

//						if (mTestCloseTime > 0) {
//							long endTestTime = System.nanoTime();
//							BigDecimal diffTest = BigDecimal.valueOf(endTestTime - mTestCloseTime, 10);//秒级差值
//							BigDecimal resultTest = diffTest.setScale(9, RoundingMode.HALF_UP);//调节精度
//							System.out.println(resultTest);
//						}
				//System.out.println(modelName+" is Run");
				//start_latch.await();

//				lock.lock();
//				AudioWaveOut.setEndLatch(2);
//				lock.unlock();

				playWaveF(m_bitDateF);
				//System.out.println(modelName+" is End playWaveF");
				System.out.println(modelName+" is End playWaveF");

				synchronized (audioTrackThread) {
					try {
//								synchronized (testThread) {
//									testThread.notify();
//								}
						//System.out.println(modelName+" is Synchronized and wait");
						audioTrackThread.wait();
						//start_latch.countDown();
					} catch (InterruptedException e) {
						e.printStackTrace();
						audioTrackThread.notify();
					}

					//System.out.println("wait");
				}

//				lock.lock();
//				end_latch.countDown();
//				//System.out.println(modelName+" is countDown : "+end_latch.getCount());
//
//				if(end_latch.getCount() == 1) {
//					lock.unlock();
//
//					try {
//						//System.out.println(modelName + "end_latch wait :" + end_latch.getCount());
//						end_latch.await();
//						//System.out.println(modelName + "end_latch wait end :" + end_latch.getCount());
//					} catch (InterruptedException e) {
//						e.printStackTrace();
//					}
//				}else {
//					try {
//						//System.out.println(modelName + "end_latch wait :" + end_latch.getCount());
//						end_latch.await();
//						//System.out.println(modelName + "end_latch wait end :" + end_latch.getCount());
//					} catch (InterruptedException e) {
//						e.printStackTrace();
//					}
//					//System.out.println(misbThreadLoop);
//					lock.unlock();
//				}
			}

			//System.out.println("run close");
			super.run();
			audioTrackThread = null;
			//SingleTonHoulder.singleTonInstance = null;
		}
	}


//		class TestThread extends Thread {
//			@Override
//			public void run() {
//				synchronized (testThread) {
//					try {
//						testThread.wait();
//
//					} catch (InterruptedException e) {
//						e.printStackTrace();
//						testThread.notify();
//					}
//
//					//System.out.println("testthread");
//				}
//
//				byte[] byteDate = new byte[]{0x55};
//				int len = byteDate.length;
//
//				sendByteDate(byteDate, len);
//			}
//		}


	protected void finalize()
	{
		if (audioTrackF != null) {
			audioTrackF.stop();
			audioTrackF.release();
			audioTrackF = null;
		}
		if (m_bitDateF != null) {
			m_bitDateF = null;
			}

		System.out.println("in finalize");
	}
}
